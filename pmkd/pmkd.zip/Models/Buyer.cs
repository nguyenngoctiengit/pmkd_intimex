﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pmkd.Models
{
    public partial class Buyer
    {
        public string Cbuyer { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string Buyer1 { get; set; }
        public string Chatluong { get; set; }
        public string Ten { get; set; }
        public byte[] TimestampColumn { get; set; }
    }
}
