﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pmkd.Models
{
    public partial class Carrier
    {
        public string Code { get; set; }
        public string Ma { get; set; }
    }
}
