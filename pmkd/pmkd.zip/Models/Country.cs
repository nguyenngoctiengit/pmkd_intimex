﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pmkd.Models
{
    public partial class Country
    {
        public string TenQg { get; set; }
        public string MaQg { get; set; }
        public string CodeQg { get; set; }
    }
}
