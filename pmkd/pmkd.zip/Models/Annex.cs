﻿using System;
using System.Collections.Generic;

#nullable disable

namespace pmkd.Models
{
    public partial class Annex
    {
        public long Id { get; set; }
        public string MaNhom { get; set; }
        public string NoiDung { get; set; }
    }
}
